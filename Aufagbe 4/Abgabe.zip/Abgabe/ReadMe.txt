Im Ordner Aufgabe4 befindet sich das Eclipse-Projekt.
Im Ordner Packages sind alle notwendinge Packages zur Ausführung abgelegt.

Um eine Station zu starten, wird folgender Befehl ausgeführt:

	java datasource.DataSource 9 <StationNummer> | java station.Starter <Adapter> <MulticastAdress> <Port> <StationTyp> [<StartDerivation>] 

Das vorgegebene Startscript startStations.sh ist vorkonfiguriert.