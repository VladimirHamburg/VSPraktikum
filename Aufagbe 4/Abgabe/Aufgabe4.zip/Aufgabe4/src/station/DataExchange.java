package station;

import java.net.DatagramPacket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataExchange {
	private SlotManager slotMan;
	private TimeManager timeMan;
	private List<Packet> buffer;
	private Long timeIn;
	private Packet next = null;
	private HashMap<Long, List<Packet>> dataSave;
	
	public DataExchange(SlotManager slotMan, TimeManager timeMan) {
		this.slotMan = slotMan;
		this.timeMan = timeMan;
		this.buffer = new ArrayList<Packet>();
		dataSave = new HashMap<Long, List<Packet>>();
	}
	
	public  void storePacket(DatagramPacket packet){
		Packet packet1 = new Packet(packet.getData());
		//buffer.add(new Packet(packet.getData()));
		Long key = packet1.getTimestamp()/40L;
		if(dataSave.containsKey(key)){
			dataSave.get(key).add(packet1);
		}else{
			ArrayList<Packet> packdata = new ArrayList<Packet>();
			packdata.add(packet1);
			dataSave.put(key, packdata);
		}
		timeIn = timeMan.getTimestamp();
	}
	
	public synchronized void proceed(Long frameN){
		for (List<Packet> packet : dataSave.values()) {
			if(packet.size() >= 2){
				//System.out.println("KOLLISION " + frameN +  " " + packet.get(0).getTimestamp() + " " + packet.get(1).getTimestamp());
				System.out.println("KOLLISION IN" + timeMan.getFrameNumUTC());
				slotMan.addBobo();
				if(slotMan.transferSenden){
					System.out.println("STATION SENT TOO");
				}
				slotMan.transferSenden = false;
			}else{
				Packet workPacket = packet.get(0);
				//Sequenzdiagramm 9
				timeMan.setTime(workPacket.getStation(), workPacket.getTimestamp()+(timeMan.getTimestamp()-timeIn));
				//Sequenzdiagramm 8
				//System.out.println(workPacket.getSlotNum() + " in frame " + timeMan.getFrameNumUTC() + " in slot " + timeMan.getSlotNum(timeMan.getTimestamp()));
				slotMan.setReceivedSlot(workPacket.getSlotNum());
				slotMan.workSlotsA.add(new Integer(workPacket.getSlotNum()));
				slotMan.transferSenden = false;
			}
		}
		
		dataSave = new HashMap<Long, List<Packet>>();
		
	}
}
	
	
	

