package station;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.CopyOnWriteArrayList;

public class SlotManager{
	Integer[] slots = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25};
	Integer[] oldSlots = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25};
	public ArrayList<Integer> workSlotsA = new ArrayList<Integer>();
	ArrayList<Integer> workSlots = new ArrayList<Integer>(Arrays.asList(slots));
	ArrayList<Integer> workSlotsOld = new ArrayList<Integer>(Arrays.asList(slots));
	private ArrayList<Integer> workSlotsStand = new ArrayList<Integer>();
	private int frameNum = 1;
	private int slot = 0;
	
	public boolean init = false;
	public boolean transferSenden;
	public boolean transferSendenW;
	
	private TimeManager timeMan;
	public SlotManager(TimeManager timeMan) {
		this.timeMan = timeMan;
		Collections.shuffle(workSlotsStand);
		for (int i = 0; i < 25; i++) {
			workSlotsStand.add(new Integer(i));
		}
	}
	
	
	public synchronized int getSlot(){
		//System.out.println(workSlotsA.toString());
		if(workSlotsA.size() <= 1){
			workSlotsA.clear();
			return -1;
		}else if(!workSlotsA.get(0).equals(workSlotsA.get(1))){
			workSlotsA.clear();
			return -1;
		}else if(workSlots.size() == 0){
			workSlotsA.clear();
			return -1;
		}else{
			//System.out.println("ASK SLOT : " + workSlots.toString() + " IN FRAME: " + timeMan.getFrameNumUTC());
			slot = (int) workSlots.get(0);
			workSlotsA.clear();
			workSlotsA.add(new Integer(slot));
			return slot;
		}
	}
	
	public  synchronized int getOldSlot(){
		ArrayList<Integer> workSlotsWWW = workSlotsOld;
		//System.out.println("ASK OLD SLOT : " + workSlotsWWW.toString() + " IN FRAME: " + timeMan.getFrameNumUTC());
		workSlotsA.add(workSlotsWWW.get(0));
    	workSlotsA.add(workSlotsWWW.get(0));
		return (int) workSlotsWWW.get(0);
	}
	
	public synchronized void setReceivedSlot(int slot){	//Sequenzdiagramm 8
		//System.out.println(" REMOVE " + slot);
		workSlotsA.add(new Integer(slot));
		if(init){
			workSlotsOld.remove(new Integer(slot));
		}
		
		workSlots.remove(new Integer(slot));
		//System.out.println(slot + " IN FRAME :" + timeMan.getFrameNumUTC());
	}
	
	public synchronized void nextFrame(int frameNum){
		slot = 0;
		//System.out.println(" OLD SLOTS IN THIS FRAME(  "+(timeMan.getFrameNumUTC()-1L) +" ): " + workSlots);
		workSlots.clear();
		for (int i = 0; i < 25; i++) {
			workSlots.add(new Integer(i+1));
		}
		Collections.shuffle(workSlots);
		this.frameNum = frameNum;
		//System.out.println("-------------NEXT FRAME----------------" + timeMan.getFrameNumUTC());
	}

	public void setKol(){
	}
	
	public synchronized void initOld(){
		workSlotsOld = new ArrayList<Integer>(Arrays.asList(slots));
		Collections.shuffle(workSlotsOld);
//		for (int i = 0; i < 25; i++) {
//			oldSlots[i] = i+1;
//		}
	}
	
	public void addBobo(){
		workSlotsA.add(new Integer(-1));
	}
	
}
