-module(koordinator).

% Exportierte Funktionen
-export([
			start/0
		]).

-import(teamtool, [toStr/1, nl/0]).

-define(TIMEOUT,5000).

logfile() -> "Koordinator@"++element(2, inet:gethostname())++".log".
config() -> "koordinator.cfg".






start() ->
  LogMsgStart = io_lib:format(
    "Koordinator-ko@~s Startzeit: ~s mit PID ~w~n",
    [node(),werkzeug:timeMilliSecond(),self()]
  ),
  werkzeug:logging(logfile(),LogMsgStart),
	{ArbeitsZeit, TermZeit, GGTProzessnummer, NSAddr, KoordinatorName, Quota, Korrigieren} = readConfig(),
  % Das process dictionary wird verwendet, um konfigurationswerte zu verwalten, weil dies einen
  % einfachen zugriff im gesamten prozess auf die werte ermöglicht und nicht problematisch ist, wenn die
  % werte nur einmal ins process dictionary eingetragen werden (wiederholtes setzen wäre kritisch)
  put(arbeitszeit,ArbeitsZeit),
  put(termzeit,TermZeit),
  put(ggtprozessnummer,GGTProzessnummer),
  put(quote, Quota),
  put(nsaddr, NSAddr),
  put(koordinatorname,KoordinatorName),
  % 'korrigieren' soll mittels 'toggle' mutable sein, daher wird das nicht im prozess-dictionary verwaltet.

	
	register(KoordinatorName, self()),

  % korrigieren zu true und false umkodieren
  KorrigierenBool = case Korrigieren of
                      0 -> false;
                      1 -> true end,

  % einmal den initialen zustand von korrigieren merken, vereinfacht reset/1
  put(initial_korrigieren, KorrigierenBool),


	% State: 'initial' <-> 'ready' -> 'terminate' und 'initial' -> 'terminate'
  switchToInitial(KorrigierenBool),
	ok.

switchToInitial(Korrigieren) ->
  GGTProcesses = [],
  werkzeug:logging(logfile(), "Koordinator wechselt nun in den Zustand 'initial'." ++ nl()),
  %Rebind durchführen
  teamtool:getNSRealAddr(get(nsaddr)) ! {self(), {rebind, get(koordinatorname), node()}},
  loopInitial(Korrigieren, GGTProcesses,0).

readConfig() ->
	% Wenn der match fehlschlaegt ist die Config-Datei vermutlich nicht
	% richtig, dann wird gecrasht!
	{ok, ConfigListe} = file:consult(config()),
	% -> funktion werkzeug:get_config_value/2
	{ok, ArbeitsZeit}      = werkzeug:get_config_value(arbeitszeit, ConfigListe),
	{ok, TermZeit}         = werkzeug:get_config_value(termzeit, ConfigListe),
	{ok, GGTProzessnummer} = werkzeug:get_config_value(ggtprozessnummer, ConfigListe),
	{ok, Nameservicenode}  = werkzeug:get_config_value(nameservicenode, ConfigListe),
	{ok, Nameservicename}  = werkzeug:get_config_value(nameservicename, ConfigListe),
	{ok, KoordinatorName}  = werkzeug:get_config_value(koordinatorname, ConfigListe),
	{ok, Quota}            = werkzeug:get_config_value(quote, ConfigListe),
	{ok, Korrigieren}      = werkzeug:get_config_value(korrigieren, ConfigListe),
	NSAddr = {Nameservicename, Nameservicenode},
	
	{ArbeitsZeit, TermZeit, GGTProzessnummer, NSAddr, KoordinatorName, Quota, Korrigieren}
.

%Stellt den zustand "initial" dar

loopInitial(Korrigieren, GGTProcesses,QuotaCurr) ->
  werkzeug:logging(logfile(),"DEBUG: loopInitial anfang"++nl()), %Logausgabe fürs Debugging
  receive
    {From, getsteeringval} ->
      % Die 9 bei "getsteeringval: <6839.40.0> (9)" aus Koordinator@Brummpa.log
      % ist die anzahl der angemeldeten ggt-Prozesse.
      LogMsg = io_lib:format("getsteeringval: ~w ~n",[From]),
      werkzeug:logging(logfile(),LogMsg),
      % Aktuelle quota berechnen
      % Die Abstimmungsquote berechnet sich aus der zum Zeitpunkt der Abfrage bekannten
      % Anzahl an erwarteten ggT-Prozessen.
      QuotaNew = QuotaCurr + round(get(ggtprozessnummer) * (get(quote)/100)),
      From ! { steeringval, get(arbeitszeit), get(termzeit), QuotaNew, get(ggtprozessnummer)},
      loopInitial(Korrigieren, GGTProcesses,  QuotaNew); % QuotaNew hier oder QuotaCurr + get(ggtprozessnummer) ?
    % Client will sich registrieren
    {hello, Clientname} ->
      werkzeug:logging(logfile(),io_lib:format("Client ~s hat sich registriert. ~n", [Clientname])),
      loopInitial(Korrigieren, [Clientname|GGTProcesses], QuotaCurr);
    % Manuelle eingabe
    step ->
      werkzeug:logging(logfile(), "'step' erhalten. Baue nun den Ring der ggT-Prozesse." ++nl()),
      %Durchmische die liste, damit es weniger wahrscheinlicher ist, dass nachbaren sich auf dem gleichen rechner befinden
      GGTProcessesShuffled = werkzeug:shuffle(GGTProcesses),
      createRing(GGTProcessesShuffled),
      switchToReady(Korrigieren,GGTProcessesShuffled);
    reset ->
      reset(GGTProcesses);
    prompt ->
      prompt(GGTProcesses);
    nudge ->
      nudge(GGTProcesses);
    toggle ->
      % Umstellen
      NewKorrigieren = not Korrigieren,
      % Loggen
      LogMsg = io_lib:format("Korrigieren wird von ~w auf ~w umgestellt.~n", [Korrigieren,NewKorrigieren]),
      werkzeug:logging(logfile(),LogMsg),
      % Zustand wechseln
      loopInitial(NewKorrigieren, GGTProcesses, QuotaCurr);
    kill ->
      switchToTerminate(GGTProcesses);
    Call ->
      unknownRemoteCall(Call)
  end,
  loopInitial(Korrigieren,GGTProcesses, QuotaCurr).

switchToReady(Korrigieren,GGTProcesses) ->
  werkzeug:logging(logfile(),"Koordinator wechselt nun in den zustand 'ready'." ++nl()),
  loopReady(Korrigieren,GGTProcesses,not_set).



% Weist der liste von angemeldeten GGT-Prozessen ihre nachbaren zu, sodass eine anordnung im ring entsteht.
createRing(GGTProcesses) ->
  % Schritt 1: Aus der Liste GGTProcesses = [p1, p2, p3, p4, p5] eine liste
  % GGTProcessRing = [{p5,p1,p2}, {p1,p2,p3}, {p2,p3,p4}, {p3,p4,p5}, {p4,p5,p1}] erstellen
  GGTProcessRing = makeNeighborList(GGTProcesses),
  % Über den GGTProcessRing iterieren und bei jedem prozess die nachbaren setzen
  lists:foreach(fun assignNeighbors/1, GGTProcessRing).

makeNeighborList(GGTProcesses) ->
  [First,Second|_] = GGTProcesses,
  Last = lists:last(GGTProcesses),
  Penultimate = lists:last(lists:droplast(GGTProcesses)),
  %Das ende und der anfang der ring-liste sind sonderfälle.
  [{Last,First,Second}| makeNeighborList(GGTProcesses, {Penultimate,Last,First}) ].


%rekursionsabbruch
makeNeighborList([],LastElement) -> [LastElement];

%rekursionsschritt
makeNeighborList([Left,Middle,Right|Rest], LastElement) ->
  %Liste immer um einen kleiner machen
  [{Left,Middle,Right}| makeNeighborList([Middle,Right|Rest], LastElement)];

%Sonderbehandlung für listen kleiner als 3
makeNeighborList(List, LastElement) when length(List) =< 2 ->
  makeNeighborList([], LastElement). %Einfach direkt zum ende springen

% Weist einem prozess seinen linken und rechten nachbaren zu.
assignNeighbors({LeftNeighbor,ProcessName,RightNeighbor}) ->
  %Lookup des ggT-Prozesses
  Process = teamtool:getAddr(get('nsaddr'),ProcessName),
  % Wenn der Prozess nicht gefunden wurde ist etwas generell schief
  LogMsg = "Der Prozess " ++ toStr(ProcessName) ++ " bekommt den linken nachbar " ++ toStr(LeftNeighbor) ++
    " und den rechten Nachbar " ++ toStr(RightNeighbor)  ++ " ." ++nl(),
  werkzeug:logging(logfile(), LogMsg),
  Process ! {setneighbors,LeftNeighbor,RightNeighbor}.



loopReady(Korrigieren, GGTProcesses, LowestMiKnown) ->
  werkzeug:logging(logfile(),"DEBUG: loopReady anfang"++nl()), % Logausgabe fürs debugging
	receive
		{briefmi,{Clientname,CMi,CZeit}} ->
			logbriefmi(Clientname,CMi,CZeit),
      if CMi < LowestMiKnown -> LogMsg = io_lib:format("LowestMiKnown wird aktualisiert: ~B -> ~B~n", [LowestMiKnown,CMi]),
                                werkzeug:logging(logfile(),LogMsg),
                                loopReady(Korrigieren, GGTProcesses, CMi); % dann aktualisieren
         true -> loopReady(Korrigieren,GGTProcesses,LowestMiKnown) % "else do nothing"
      end;
		{From,briefterm,{Clientname,CMi,CZeit}} ->
      if CMi > LowestMiKnown -> logbriefterm(Clientname, CMi, CZeit, "falsche"),
                                sendCorrectMi(From, LowestMiKnown, Korrigieren);
         true -> logbriefterm(Clientname,CMi,CZeit, "")
      end;
		reset ->
			reset(GGTProcesses);
		prompt ->
      prompt(GGTProcesses);
		nudge ->
			nudge(GGTProcesses);
		toggle ->
      % Umstellen
      NewKorrigieren = not Korrigieren,
      % Loggen
      LogMsg = io_lib:format("Korrigieren wird von ~w auf ~w umgestellt.~n", [Korrigieren,NewKorrigieren]),
      werkzeug:logging(logfile(),LogMsg),
      % Zustand wechseln
      loopReady(NewKorrigieren, GGTProcesses, LowestMiKnown);
		{calc,WggT} ->
      % Ich denke wenn man das Mi auf den wert unten setzt, wird man die meisten aktualisierungen
      %  an LowestMiKnown sehen
      LogMsg = io_lib:format(
        "~s Starte verteilte ggT-Berechnung mit Wunsch-ggT ~B",
        [werkzeug:timeMilliSecond(),WggT]
      ),
      werkzeug:logging(logfile(),LogMsg),
      HighestInitialMi = calc(GGTProcesses, WggT),
      loopReady(Korrigieren, GGTProcesses, HighestInitialMi);
		kill ->
			switchToTerminate(GGTProcesses);
		Call ->
			unknownRemoteCall(Call)
	end,
  loopReady(Korrigieren,GGTProcesses,LowestMiKnown).

switchToTerminate(GGTProcesses) ->
  werkzeug:logging(logfile(),"Koordinator wechselt nun in den zustand 'terminate'." ++nl()),
  kill(GGTProcesses).



sendCorrectMi(From, LowestMiKnown, true) ->
  From ! {sendy, LowestMiKnown};

sendCorrectMi(From, _LowestMiKnown, false) -> do_nothing, From.



% CMi: neues Mi
% CZeit: aktuelle Zeit im Format von erlang:now().
% return: ---
logbriefmi(Clientname, CMi, CZeit) ->
  LogMsg = io_lib:format(
    "~s meldet neues Mi ~B um "++werkzeug:timeMilliSecond()++" (~s).~n",
    [Clientname, CMi, CZeit]
  ),
  werkzeug:logging(logfile(), LogMsg).


% Information über Terminierung der Berechnung mit Ergebnis CMi um CZeit Uhr.
% return: ---

logbriefterm(Clientname, CMi, CZeit, RightOrWrong) ->
  LogMsg = io_lib:format(
    "~s meldet"++RightOrWrong++"Terminierung mit ggT ~B um "++werkzeug:timeMilliSecond()++" (~s).~n",
    [Clientname,CMi,CZeit]
  ),
  werkzeug:logging(logfile(), LogMsg).

% Der koordinator sendet allen ggt_process Instanzen das kill-Kommando
% und bringt sich selbst in den initialen Zustand, indem sich Starter
% wieder melden können.
% return: ---
reset(GGTProcesses) ->
  NSAddr = get(nsaddr),

  killAllProcesses(NSAddr, GGTProcesses),

  switchToInitial(get(initial_korrigieren)).

killAllProcesses(NSAddr, GGTProcesses) ->
  lists:foreach(
    fun(GGTProcess) ->
      case teamtool:getAddr(NSAddr, GGTProcess) of
        not_found ->
          werkzeug:logging(logfile(), "Konnte den Namen des ggt_process auf keine Adresse auflösen." ++ nl())
      ;
        GGTProcessAddr ->
          GGTProcessAddr ! kill
      end
    end,
    GGTProcesses
  ).


% Der koordinator erfragt bei allen ggt_process Instanzen per tellmi
% deren aktuelles Mi ab und zeigt dies im Log an.
% return: ---
prompt(GGTProcesses) ->
  NSAddr = get(nsaddr),
  werkzeug:logging(logfile(),"prompt: Erfrage Mis von allen ggT-Prozessen..."++nl()),
	lists:foreach(
			fun(GGTProcess) ->
					case teamtool:getAddr(NSAddr, GGTProcess) of
						not_found ->
							werkzeug:logging(logfile(), "Konnte den Namen des ggt_process auf keine Adresse auflösen."++nl())
						;
            {GGTProcessName,GGTProcessNode} ->
              {GGTProcessName,GGTProcessNode} ! {self(), tellmi},
							receive
								{mi,Mi} ->
                  TimeStamp = werkzeug:timeMilliSecond(), %zeitstempel sofort nach empfangen der nachricht erstellen
                  LogMsg =
                    io_lib:format(
                      "ggT-Prozess ~s (~s) aktuelles Mi ~w (empfangen am ~s).~n",
                      [GGTProcessName, GGTProcessNode, Mi, TimeStamp]
                    ),
                  werkzeug:logging(logfile(),LogMsg)
              end
          end
        end,
			GGTProcesses
		),
  werkzeug:logging(logfile(),"prompt: Erfragen der Mis aller ggT-Prozesse abgeschlossen."++nl()).

% Der koordinator erfragt bei allen ggt_process Instanzen per pingGGT
% deren Lebenszustand und zeigt das Ergebnis im Log an.
% return: ---
nudge(GGTProcesses) ->
  NSAddr = get(nsaddr),
  werkzeug:logging(logfile(),"nudge: Prüfe alle ggT-Prozesse auf Lebendigkeit..."++nl()),
	lists:foreach(
			fun(GGTProcess) ->
					case teamtool:getAddr(NSAddr, GGTProcess) of
						not_found ->
							werkzeug:logging(logfile(), "Konnte den Namen des ggt_process auf keine Adresse auflösen."++nl())
						;
						{GGTProcessName,GGTProcessNode} ->
              {GGTProcessName,GGTProcessNode} ! {self(),pingGGT},
							receive
								{pongGGT,GGTname} ->
                  TimeStamp = werkzeug:timeMilliSecond(),
                  LogMsg =
                  io_lib:format(
                    "ggT-Prozess ~s (~s)  ist lebendig (empfangen am ~s).~n",
                    [GGTname, GGTProcessNode, TimeStamp]
                  ),
                  werkzeug:logging(logfile(),LogMsg)
              after ?TIMEOUT ->
                TimeStamp = werkzeug:timeMilliSecond(), %zeitstempel sofort nach empfangen der nachricht erstellen
                LogMsg =
                  io_lib:format(
                    "ggT-Prozess ~s (~s) hat sich nicht in ~B Millisekunden gemeldet (festgestellt am ~s).~n",
                    [GGTProcessName, GGTProcessNode,?TIMEOUT,TimeStamp]
                  ),
                werkzeug:logging(logfile(),LogMsg)
							end
					end
				end,
			GGTProcesses
		),werkzeug:logging(logfile(),"prompt: Prüfen der Lebendigkeit aller ggT-Prozesse abgeschlossen."++nl()).


% Der koordinator startet eine neue ggT-Berechnung mit Wunsch-ggT WggT.m
% return: ---
calc(GGTProcesses, WggT) ->
  NSAddr = get('nsaddr'),
  % 1. Die Mis erzeugen
  Mis = werkzeug:bestimme_mis(WggT,length(GGTProcesses)),
  % 2. Die Mis versenden
  werkzeug:logging(logfile(),"Sende initiale Mis..."++nl()),
  lists:foreach(
      fun({Mi,GGTProcess}) ->
          case teamtool:getAddr(NSAddr, GGTProcess) of
            not_found ->
              werkzeug:logging(logfile(), "Konnte den Namen des ggt_process auf keine Adresse auflösen."++nl())
            ;
            GGTProcessAddr ->
              LogMsg = io_lib:format("Sende Mi ~w an Prozess ~s~n", [Mi,GGTProcess]),
              werkzeug:logging(logfile(), LogMsg),
              GGTProcessAddr ! {setpm, Mi}
          end
        end,
      lists:zip(Mis,GGTProcesses)
  ),
  % 3. "Er wählt dann per Zufall 20% aller ggT-Prozesse aus, [...]"
  TwentyPercentOfProcesses = select20Percent(GGTProcesses),
  TPOPLength = length(TwentyPercentOfProcesses),
  % [...] die sich analog zu Punkt 5. berechnet."
  InitialSendYs = werkzeug:bestimme_mis(WggT,TPOPLength),
  % [...] denen er zum Start der Berechnung eine Zahl per sendy sendet, [...]
  werkzeug:logging(logfile(),"Sende initiale Y-Nachrichten..."++nl()),
  lists:foreach(
     fun({Y,GGTProcess}) ->
       case teamtool:getAddr(NSAddr, GGTProcess) of
         not_found ->
           werkzeug:logging(logfile(), "Konnte den Namen des ggt_process auf keine Adresse auflösen."++nl());
         GGTProcessAddr ->
           LogMsg = io_lib:format("Sende Y ~w an Prozess ~s~n", [Y, GGTProcess]),
           werkzeug:logging(logfile(),LogMsg),
           GGTProcessAddr ! {sendy, Y}
       end
     end,
       lists:zip(InitialSendYs,TwentyPercentOfProcesses)
  ),
  lists:max(Mis).

% wählt aus einer liste zufällig 20 prozent (aber mindestens 2) der elemente aus
select20Percent(List) ->
  Length = length(List),
  OneFifth = round(Length/5),
  selectRandomly(List,max(2,OneFifth)).

% Wählt zufällig ElemCount viele elemente aus der liste List aus und
% und gibt dann eine liste mit den ausgewählten elementen zurück.

selectRandomly(List,ElemCount) -> selectRandomly(List,ElemCount,[]).

%hilsfunktion für endrekursion
selectRandomly(_List,0,Accu) -> Accu;

selectRandomly(List,ElemCount,Accu) ->
  [RandomH|RandomT] = werkzeug:shuffle(List), %liste mischen
  selectRandomly(RandomT,ElemCount - 1, [RandomH|Accu]). % und vorderstes nehmen


% Der koordinator sendet allen ggt_process Instanzen
% das kill-Kommando beendet sich.
% return: ---
kill(GGTProcesses) ->
  NSAddr = get(nsaddr),
  % "Die ggT-Prozesse werden vom Koordinator über die Beendigung des Systems informiert (kill)."
  killAllProcesses(NSAddr,GGTProcesses),
  % "Hat der Koordinator alle ggT-Prozesse über die Beendigung informiert,
  % meldet er sich beim Namensdienst ab und beendet sich."
  teamtool:getNSRealAddr(NSAddr) ! {self(), {unbind, get(koordinatorname)}},
  receive
    ok -> io:format("..unbind..done.~n")
  end,
  unregister(get(koordinatorname)),
  LogMsg = io_lib:format(
    "Downtime: ~s vom Koordinator ~s~n",
    [werkzeug:timeMilliSecond(), get(koordinatorname)]
  ),
  werkzeug:logging(logfile(),LogMsg),
  exit(normal). % "terminate normally", siehe http://www.erlang.org/doc/reference_manual/processes.html#id84825

% return: ---
unknownRemoteCall(Call) ->
	werkzeug:logging(logfile(), "in loop unerwartete Nachricht erhalten: "++
			werkzeug:to_String(Call)++ "\r\n").
