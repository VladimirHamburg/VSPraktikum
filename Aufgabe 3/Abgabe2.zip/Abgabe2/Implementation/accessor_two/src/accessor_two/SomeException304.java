package accessor_two;

public class SomeException304 extends Exception {
	public SomeException304(String message) { super(message);} 
}
