package mware_lib;

public interface Invokeable {
	String Invoke(String[] splitData);
}
