package accessor_two;

public class SomeException112 extends Exception{
	public SomeException112(String message) { super(message);} 
}
