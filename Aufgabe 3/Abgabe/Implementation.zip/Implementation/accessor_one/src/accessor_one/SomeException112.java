package accessor_one;

public class SomeException112 extends Exception {
	public SomeException112(String message) { super(message);} 
}
