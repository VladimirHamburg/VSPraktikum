package accessor_one;

public class SomeException110 extends Exception {
	public SomeException110(String message) { super(message);} 
}
